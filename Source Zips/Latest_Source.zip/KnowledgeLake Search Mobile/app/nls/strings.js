define({
   'root': true,
   'es': true,
   'de': true
});