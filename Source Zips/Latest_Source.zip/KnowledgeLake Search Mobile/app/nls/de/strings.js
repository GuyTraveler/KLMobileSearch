define({
    appTitle: "KnowledgeLake Suche Handy"
});