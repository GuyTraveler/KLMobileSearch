define({
	adfs: "Federated",
	managed: "Managed",
	unknown: "Unknown"
});