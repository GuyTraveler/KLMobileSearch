define([], function() {
   return {
       standard: "standard",
       forward: "forward",
       back: "back"
   };
});