//these 2 strings are the return values from the SP Authentication web service "Mode" method
define({
   Windows: "Windows",
   ClaimsOrForms: "Forms"
});