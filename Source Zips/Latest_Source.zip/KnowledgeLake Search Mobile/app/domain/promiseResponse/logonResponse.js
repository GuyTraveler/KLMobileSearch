define([], function() {
   return {
       // these should all be localized
       LogonFailed: "Logon failed.",
       LogonSucceeded: "Logon succeeded."
   };
});