define([], function() {
   return {
       // these should all be localized
       SiteDataEmpty: "Site data has not been populated",
       SiteConnectionExists: "Site connection already exists.",
       InvalidSite: "Site connection does not exist."
   };
});