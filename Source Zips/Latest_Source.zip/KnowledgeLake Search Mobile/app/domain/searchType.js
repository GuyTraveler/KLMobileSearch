define([], function() {
   return {
       local: 0,
       server: 1
   };
});