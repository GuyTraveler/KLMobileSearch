define([], function() {
   return {
       configureSitePage: "#configureSite",
       documentPropertiesPage: "#document",
       homePage: "#home",
       logsPage: "#logs",
       resultsPage: "#results", 
       savedSearchPage: "#savedSearch",
       searchBuilderPage: "#searchBuilder"
   };
});