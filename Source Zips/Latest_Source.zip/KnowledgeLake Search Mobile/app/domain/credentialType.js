define([], function() {
   return {
       ntlm: 0,
       claimsOrForms: 1
   };
});