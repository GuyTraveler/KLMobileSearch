define([], function() {
   return {
       Number: "Number",
       TextBox: "TextBox",
       DropDown: "DropDown",
       Calendar: "Calendar",
       RadioButton: "RadioButton",
       ComboBox: "ComboBox"
   };
});