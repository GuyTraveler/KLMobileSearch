define(["logger"], function (logger) {
	return {
		showEmailComposer: function () {
			logger.logDebug("emailComposerMock.showEmailComposer");
        }
    }
});